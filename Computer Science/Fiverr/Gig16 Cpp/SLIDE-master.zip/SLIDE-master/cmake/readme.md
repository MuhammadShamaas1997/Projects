The files in this folder are taken and adapted from: 

https://github.com/lefticus/cpp_weekly/tree/master/cmake

Currently, they may or may not be in use. 
/*
 * examples.hpp
 *
 * to include available example headers.
 *
 *  Created on: 02 Nov 2022
 *   Author(s): Volkan Kumtepeli
 *
 */

#pragma once


#include "drive_cycles.hpp"
#include "estimation.hpp"
#include "cell_tests.hpp"

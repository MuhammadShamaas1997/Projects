/*
 * procedures.hpp
 *
 * to include available procedure headers.
 *
 *  Created on: 20 Jun 2022
 *   Author(s): Jorn Reniers, Volkan Kumtepeli
 *
 */

#pragma once

#include "Procedure.hpp"
#include "Cycler.hpp"
#include "determine_OCV.hpp"

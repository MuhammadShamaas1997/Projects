#pragma once

//!< This file is for default parameter values.

#include "SEIparam_default.hpp"
#include "LAMparam_default.hpp"
#include "StressParam_default.hpp"
#include "CSparam_default.hpp"

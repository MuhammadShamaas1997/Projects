/*
 * CSparam_default.hpp
 *
 *
 *
 *  Created on: 28 Jun 2022
 *   Author(s): Jorn Reniers, Volkan Kumtepeli
 *
 */
#pragma once

#include "CSparam.hpp"

namespace slide::param::def {
//!< Here will be some default parameters.

}
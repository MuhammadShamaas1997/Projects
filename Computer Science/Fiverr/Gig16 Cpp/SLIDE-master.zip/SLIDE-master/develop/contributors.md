# List of contributors 

Please feel free to add your name into the list! 


## Core contributors


**Jorn Reniers:** Initial developer of SLIDE. 
- creator of SLIDE and SLIDE-PACK.


**Volkan Kumtepeli:** Successor of Jorn and current maintainer of SLIDE. 
- merged SLIDE and SLIDE-PACK libraries into the unified SLIDE library.
- modernised the library to use C++20 standard. 
- built the documentation website.
- organised file structure and CMakeLists hierarchy.


**David A. Howey:** SLIDE project administrator.
- contributed via project adminstration, supervison, documentation review and editing. 


## Other contributors


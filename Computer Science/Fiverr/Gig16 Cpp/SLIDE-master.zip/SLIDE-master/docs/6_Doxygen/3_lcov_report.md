---
layout: default
title: Code coverage report (LCOV)
nav_order: 3
---
<html>
<body>
<iframe src="https://battery-intelligence-lab.github.io/SLIDE/Coverage/index.html" frameborder="0" scrolling="yes" seamless="seamless" style="display:block; width:100%; height:100vh;"></iframe>
</body>
</html>


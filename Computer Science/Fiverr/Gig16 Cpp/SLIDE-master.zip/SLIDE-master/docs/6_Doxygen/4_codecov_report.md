---
layout: default
title: Code coverage report (Codecov.io)
nav_order: 4
---
<html>
  <head>
    <meta http-equiv="refresh" content="0; url='https://app.codecov.io/gh/Battery-Intelligence-Lab/SLIDE/'" />
  </head>
  <body>
    <p>Please follow <a href="https://app.codecov.io/gh/Battery-Intelligence-Lab/SLIDE/">this link</a> for Codecov.io report.</p>
  </body>
</html>
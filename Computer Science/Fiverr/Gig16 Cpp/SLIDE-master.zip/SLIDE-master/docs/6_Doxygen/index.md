---
layout: default
title: API Documentation
nav_order: 1
---

Here you may find API related documentation and test results. 

[Doxygen generated documentation](2_doxygen.md)

[Code coverage report (LCOV)](3_lcov_report.md)

[Code coverage report (Codecov.io)](https://app.codecov.io/gh/Battery-Intelligence-Lab/SLIDE/)

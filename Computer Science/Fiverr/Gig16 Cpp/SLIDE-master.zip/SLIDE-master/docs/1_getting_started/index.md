---
layout: default
title: Getting Started
nav_order: 1
---


# Getting started

[Installation](2_installation.md) \
[Running the code](3_running.md) 
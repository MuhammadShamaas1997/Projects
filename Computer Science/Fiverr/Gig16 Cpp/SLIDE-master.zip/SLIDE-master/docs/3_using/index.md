---
layout: default
title: Usage
nav_order: 1
---


# Using SLIDE Software

[Cycling](2_cycling.md)\
[Degradation](3_degradation.md)\
[OCV parametrisation](4_ocv_parametrisation.md)\
[Characterisation parametrisation](5_character_parametrisation.md)
---
layout: default
title: Overview
nav_order: 1
---


# Overview

[Goal](2_goal.md) \
[Mathematics](3_mathematics.md) \
[MATLAB setup](4_matlab_setup.md) \
[C++ code](5_cpp_code.md)
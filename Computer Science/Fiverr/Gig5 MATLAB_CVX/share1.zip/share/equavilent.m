function [H2,H1,G,A]=equavilent(Hbsue,Hirsue,Hbsirs,Hirstg)
    H2=Hbsue;
    H1=Hirsue;
    G=Hbsirs;
    A=Hirstg;
end
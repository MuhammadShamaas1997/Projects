function DisBS2IRS=caldisirs(BSloca,IRSloca)
         DisBS2IRS=norm(BSloca-IRSloca);
end
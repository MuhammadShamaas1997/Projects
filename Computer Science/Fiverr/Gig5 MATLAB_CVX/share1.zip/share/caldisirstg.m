function DisIRS2TG=caldisirstg(IRSloca,TGloca)
    DisIRS2TG=norm(IRSloca-TGloca);
end